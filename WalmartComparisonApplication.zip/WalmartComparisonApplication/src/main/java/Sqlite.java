import java.io.IOException;
import java.sql.*;

//create the sqlite class for connection with the database
public class Sqlite {
    Connection conn;

    Sqlite() throws IOException {
    }

    //make initial connection to database
    //makes the initial connection to the database (Professor Noynaert's code)
    public boolean makeConnection(String fileName) {
        boolean successfullyOpened = false;

        String connectString = "jdbc:sqlite:" + fileName;
        try {
            conn = DriverManager.getConnection(connectString);
            if (conn != null) {
                successfullyOpened = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            successfullyOpened = false;
        }
        return successfullyOpened;
    }

    public void insert(String tableName, String itemID, String name, String salePrice, String category, String shortDesc,
                       String longDesc, String thumbnailImage, String mediumImage, String largeImage,
                       String productURL, String custRating, String numReviews, String availability) throws SQLException {
        //create statement
        Statement statement = conn.createStatement();

        //formats query string
        String queryString = String.format("insert into %s values (\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\");",
                tableName, itemID, name.replaceAll("\"",""), salePrice, category,
                shortDesc, longDesc, thumbnailImage, mediumImage, largeImage, productURL,
                custRating, numReviews, availability);

        //execute and close the statement
        statement.executeUpdate(queryString);

    }

    void clear(String tableName) {
        try {
            //create a statement
            Statement stmt = conn.createStatement();

            //formats the string to be able to execute the query successfully
            String queryString = String.format
                    ("DELETE FROM %s;", tableName);

            //executes the query and then closes the statement
            stmt.executeUpdate(queryString);
            stmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //print out the specified item info
    public String getInfo(String tableName, int row) {
        try {
            //formats the string to be able to execute the query successfully
            String queryString = String.format
                    ("select salePrice, name, shortDesc, custRating, numReviews, availability " +
                            "from inventory order by salePrice limit 1 offset %d;",row-1);

            //get info for printing out the table
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(queryString);

            //format the return string
            String info = String.format("$%s\t\t%s\n%s\nCustomer rating: %s\t\tNumber of Ratings: %s\t\t%s",
                    rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));

            //return the formatted string
            return info;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "";
    }

    //get image
    public String getImage(String tableName, int row) {
        try {
            //formats the string to be able to execute the query successfully
            String queryString = String.format
                    ("select thumbnailImage from inventory order by salePrice limit 1 offset %d;",row-1);

            //get info for printing out the table
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(queryString);

            //return the image url
            return rs.getString(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "";
    }


    //close the connection
    public void close() {
        try {
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

