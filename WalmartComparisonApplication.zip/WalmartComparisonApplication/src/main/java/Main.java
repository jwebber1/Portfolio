import java.io.File;
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Main extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        //set the stage
        primaryStage.setTitle("Walmart Comparison Application");

        //create tabpane
        TabPane tp = new TabPane();
        Tab tab1 = new Tab("Search by name");


        tp.getTabs().add(tab1);
        tp.prefWidthProperty().bind(primaryStage.widthProperty());

        new Search_by_name(tab1).open();


        //creating layout of Scene
        GridPane layout = new GridPane();
        layout.getChildren().add(tp);
        layout.setPrefHeight(725);


        File file = new File("C:\\Users\\Jon\\Dropbox\\Sp2018_classes\\Data Exchange Technologies\\Final Project\\WalmartOpenAPI.png");
        Image image = new Image(file.toURI().toString());
        ImageView logo = new ImageView(image);
        logo.setImage(image);
        logo.setFitWidth(150);
        logo.setFitHeight(150);
        logo.setPreserveRatio(true);
        logo.setSmooth(true);
        GridPane.setConstraints(logo, 0, 1);
        GridPane.setHalignment(logo, HPos.RIGHT);
        layout.getChildren().add(logo);

        Scene mainScene = new Scene(layout, 1250, 725);
        primaryStage.setScene(mainScene);
        primaryStage.show();
    }
}