import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.image.ImageView;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static javafx.scene.control.Alert.*;

public class Search_by_name {

    Tab tab;

    //constructor
    public Search_by_name(Tab tab){
        this.tab = tab;
    }

    //method
    public void open(){
        //creating layout of tab
        GridPane layout = new GridPane();
        layout.setPrefHeight(725);

        //contents of the tab

        //create a label
        Label searchTerm = new Label("Search Term");
        GridPane.setConstraints(searchTerm,0,0);
        layout.getChildren().add(searchTerm);

        //create input field
        TextField inputTerm = new TextField();
        GridPane.setConstraints(inputTerm,0,1);
        inputTerm.setMaxWidth(400);
        inputTerm.setPromptText("ipod");
        layout.getChildren().add(inputTerm);

        //create button
        Button search = new Button("Search");
        GridPane.setConstraints(search,0,2);
        GridPane.setHalignment(search, HPos.RIGHT);
        layout.getChildren().add(search);

        //search with term
        search.setOnAction(new EventHandler<ActionEvent>() {
            int click = 0;
            RadioButton rdo0 = null;
            RadioButton rdo1 = null;
            RadioButton rdo2 = null;
            RadioButton rdo3 = null;
            RadioButton rdo4 = null;
            RadioButton rdo5 = null;
            RadioButton rdo6 = null;
            RadioButton rdo7 = null;
            RadioButton rdo8 = null;
            RadioButton rdo9 = null;
            ImageView pic0 = null;
            ImageView pic1 = null;
            ImageView pic2 = null;
            ImageView pic3 = null;
            ImageView pic4 = null;
            ImageView pic5 = null;
            ImageView pic6 = null;
            ImageView pic7 = null;
            ImageView pic8 = null;
            ImageView pic9 = null;
            final ToggleGroup group = new ToggleGroup();
            @Override
            public void handle(ActionEvent event) {
                if (click == 0) {
                    if (inputTerm.getLength() == 0) {
                        Alert alert = new Alert(AlertType.ERROR);
                        alert.setTitle("Error");
                        alert.setHeaderText("No text inserted into search bar.");
                        alert.showAndWait();

                    } else {
                        Sqlite db = null;
                        try {
                            db = new Sqlite();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        db.makeConnection("WalmartDB.db");


                        //format string for the website to scrape
                        String urlString = getQueryWord(inputTerm.getText());

                        //create xml file from website
                        try {
                            toXMLfile(urlString);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        List<WItem> inventory = makeList("XMLfiles/Walmart" + getDate() + ".xml");

                        try {
                            fillDatabase(inventory, db);
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }




                        //radio buttons and images
                        rdo0 = new RadioButton(db.getInfo("inventory", 1));
                        rdo0.setToggleGroup(group);
                        rdo0.setSelected(true);
                        GridPane.setConstraints(rdo0, 0, 3);
                        GridPane.setMargin(rdo0, new Insets(2));
                        //Image image0 = new Image(db.getImage("inventory",1));
                        ImageView pic0 = new ImageView(db.getImage("inventory",1));
                        GridPane.setConstraints(pic0,1,3);

                        rdo1 = new RadioButton(db.getInfo("inventory", 2));
                        rdo1.setToggleGroup(group);
                        GridPane.setConstraints(rdo1, 0, 4);
                        GridPane.setMargin(rdo1, new Insets(2));
                        //Image image1 = new Image(db.getImage("inventory",2));
                        ImageView pic1 = new ImageView(db.getImage("inventory",2));
                        GridPane.setConstraints(pic1,1,4);

                        rdo2 = new RadioButton(db.getInfo("inventory", 3));
                        rdo2.setToggleGroup(group);
                        GridPane.setConstraints(rdo2, 0, 5);
                        GridPane.setMargin(rdo2, new Insets(2));
                        //Image image2 = new Image(db.getImage("inventory",3));
                        ImageView pic2 = new ImageView(db.getImage("inventory",3));
                        GridPane.setConstraints(pic2,1,5);

                        rdo3 = new RadioButton(db.getInfo("inventory", 4));
                        rdo3.setToggleGroup(group);
                        GridPane.setConstraints(rdo3, 0, 6);
                        GridPane.setMargin(rdo3, new Insets(2));
                        //Image image3 = new Image(db.getImage("inventory",4));
                        ImageView pic3 = new ImageView(db.getImage("inventory",4));
                        GridPane.setConstraints(pic3,1,6);

                        rdo4 = new RadioButton(db.getInfo("inventory", 5));
                        rdo4.setToggleGroup(group);
                        GridPane.setConstraints(rdo4, 0, 7);
                        GridPane.setMargin(rdo4, new Insets(2));
                        //Image image4 = new Image(db.getImage("inventory",5));
                        ImageView pic4 = new ImageView(db.getImage("inventory",5));
                        GridPane.setConstraints(pic4,1,7);

                        rdo5 = new RadioButton(db.getInfo("inventory", 6));
                        rdo5.setToggleGroup(group);
                        GridPane.setConstraints(rdo5, 0, 8);
                        GridPane.setMargin(rdo5, new Insets(2));
                        //Image image5 = new Image(db.getImage("inventory",6));
                        ImageView pic5 = new ImageView(db.getImage("inventory",6));
                        GridPane.setConstraints(pic5,1,8);

                        rdo6 = new RadioButton(db.getInfo("inventory", 7));
                        rdo6.setToggleGroup(group);
                        GridPane.setConstraints(rdo6, 0, 9);
                        GridPane.setMargin(rdo6, new Insets(2));
                        //Image image6 = new Image(db.getImage("inventory",7));
                        ImageView pic6 = new ImageView(db.getImage("inventory",7));
                        GridPane.setConstraints(pic6,1,9);

                        rdo7 = new RadioButton(db.getInfo("inventory", 8));
                        rdo7.setToggleGroup(group);
                        GridPane.setConstraints(rdo7, 0, 10);
                        GridPane.setMargin(rdo7, new Insets(2));
                        //Image image7 = new Image(db.getImage("inventory",8));
                        ImageView pic7 = new ImageView(db.getImage("inventory",8));
                        GridPane.setConstraints(pic7,1,10);

                        rdo8 = new RadioButton(db.getInfo("inventory", 9));
                        rdo8.setToggleGroup(group);
                        GridPane.setConstraints(rdo8, 0, 11);
                        GridPane.setMargin(rdo8, new Insets(2));
                        //Image image8 = new Image(db.getImage("inventory",9));
                        ImageView pic8 = new ImageView(db.getImage("inventory",9));
                        GridPane.setConstraints(pic8,1,11);

                        rdo9 = new RadioButton(db.getInfo("inventory", 10));
                        rdo9.setToggleGroup(group);
                        GridPane.setConstraints(rdo9, 0, 12);
                        GridPane.setMargin(rdo9, new Insets(2));
                        //Image image9 = new Image(db.getImage("inventory",10));
                        ImageView pic9 = new ImageView(db.getImage("inventory",10));
                        GridPane.setConstraints(pic9,1,12);

                        pic0.setFitWidth(50);pic0.setFitHeight(50);
                        pic1.setFitWidth(50);pic1.setFitHeight(50);
                        pic2.setFitWidth(50);pic2.setFitHeight(50);
                        pic3.setFitWidth(50);pic3.setFitHeight(50);
                        pic4.setFitWidth(50);pic4.setFitHeight(50);
                        pic5.setFitWidth(50);pic5.setFitHeight(50);
                        pic6.setFitWidth(50);pic6.setFitHeight(50);
                        pic7.setFitWidth(50);pic7.setFitHeight(50);
                        pic8.setFitWidth(50);pic8.setFitHeight(50);
                        pic9.setFitWidth(50);pic9.setFitHeight(50);

                        layout.getChildren().addAll(rdo0, rdo1, rdo2, rdo3, rdo4, rdo5, rdo6, rdo7, rdo8, rdo9);
                        layout.getChildren().addAll(pic0,pic1,pic2,pic3,pic4,pic5,pic6,pic7,pic8,pic9);
                        db.close();

                    }
                    click++;
                    Button addToCart = new Button("Add to Cart");
                    GridPane.setConstraints(addToCart,0,13);
                    layout.getChildren().add(addToCart);

                } else {
                    if (inputTerm.getLength() == 0) {
                        Alert alert = new Alert(AlertType.ERROR);
                        alert.setTitle("Error");
                        alert.setHeaderText("No text inserted into search bar.");
                        alert.showAndWait();

                    } else {
                        Sqlite db = null;
                        try {
                            db = new Sqlite();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        db.makeConnection("WalmartDB.db");


                        //format string for the website to scrape
                        String urlString = getQueryWord(inputTerm.getText());

                        //create xml file from website
                        try {
                            toXMLfile(urlString);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        List<WItem> inventory = makeList("XMLfiles/Walmart" + getDate() + ".xml");

                        try {
                            fillDatabase(inventory, db);
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }


                        layout.getChildren().removeAll(rdo0, rdo1, rdo2, rdo3, rdo4, rdo5, rdo6, rdo7, rdo8, rdo9,
                                pic0, pic1, pic2, pic3, pic4, pic5, pic6, pic7, pic8, pic9);

                        //radio buttons and images
                        rdo0 = new RadioButton(db.getInfo("inventory", 1));
                        rdo0.setToggleGroup(group);
                        rdo0.setSelected(true);
                        GridPane.setConstraints(rdo0, 0, 3);
                        GridPane.setMargin(rdo0, new Insets(2));
                        //Image image0 = new Image(db.getImage("inventory",1));
                        ImageView pic0 = new ImageView(db.getImage("inventory",1));
                        GridPane.setConstraints(pic0,1,3);

                        rdo1 = new RadioButton(db.getInfo("inventory", 2));
                        rdo1.setToggleGroup(group);
                        GridPane.setConstraints(rdo1, 0, 4);
                        GridPane.setMargin(rdo1, new Insets(2));
                        //Image image1 = new Image(db.getImage("inventory",2));
                        ImageView pic1 = new ImageView(db.getImage("inventory",2));
                        GridPane.setConstraints(pic1,1,4);

                        rdo2 = new RadioButton(db.getInfo("inventory", 3));
                        rdo2.setToggleGroup(group);
                        GridPane.setConstraints(rdo2, 0, 5);
                        GridPane.setMargin(rdo2, new Insets(2));
                        //Image image2 = new Image(db.getImage("inventory",3));
                        ImageView pic2 = new ImageView(db.getImage("inventory",3));
                        GridPane.setConstraints(pic2,1,5);

                        rdo3 = new RadioButton(db.getInfo("inventory", 4));
                        rdo3.setToggleGroup(group);
                        GridPane.setConstraints(rdo3, 0, 6);
                        GridPane.setMargin(rdo3, new Insets(2));
                        //Image image3 = new Image(db.getImage("inventory",4));
                        ImageView pic3 = new ImageView(db.getImage("inventory",4));
                        GridPane.setConstraints(pic3,1,6);

                        rdo4 = new RadioButton(db.getInfo("inventory", 5));
                        rdo4.setToggleGroup(group);
                        GridPane.setConstraints(rdo4, 0, 7);
                        GridPane.setMargin(rdo4, new Insets(2));
                        //Image image4 = new Image(db.getImage("inventory",5));
                        ImageView pic4 = new ImageView(db.getImage("inventory",5));
                        GridPane.setConstraints(pic4,1,7);

                        rdo5 = new RadioButton(db.getInfo("inventory", 6));
                        rdo5.setToggleGroup(group);
                        GridPane.setConstraints(rdo5, 0, 8);
                        GridPane.setMargin(rdo5, new Insets(2));
                        //Image image5 = new Image(db.getImage("inventory",6));
                        ImageView pic5 = new ImageView(db.getImage("inventory",6));
                        GridPane.setConstraints(pic5,1,8);

                        rdo6 = new RadioButton(db.getInfo("inventory", 7));
                        rdo6.setToggleGroup(group);
                        GridPane.setConstraints(rdo6, 0, 9);
                        GridPane.setMargin(rdo6, new Insets(2));
                        //Image image6 = new Image(db.getImage("inventory",7));
                        ImageView pic6 = new ImageView(db.getImage("inventory",7));
                        GridPane.setConstraints(pic6,1,9);

                        rdo7 = new RadioButton(db.getInfo("inventory", 8));
                        rdo7.setToggleGroup(group);
                        GridPane.setConstraints(rdo7, 0, 10);
                        GridPane.setMargin(rdo7, new Insets(2));
                        //Image image7 = new Image(db.getImage("inventory",8));
                        ImageView pic7 = new ImageView(db.getImage("inventory",8));
                        GridPane.setConstraints(pic7,1,10);

                        rdo8 = new RadioButton(db.getInfo("inventory", 9));
                        rdo8.setToggleGroup(group);
                        GridPane.setConstraints(rdo8, 0, 11);
                        GridPane.setMargin(rdo8, new Insets(2));
                        //Image image8 = new Image(db.getImage("inventory",9));
                        ImageView pic8 = new ImageView(db.getImage("inventory",9));
                        GridPane.setConstraints(pic8,1,11);

                        rdo9 = new RadioButton(db.getInfo("inventory", 10));
                        rdo9.setToggleGroup(group);
                        GridPane.setConstraints(rdo9, 0, 12);
                        GridPane.setMargin(rdo9, new Insets(2));
                        //Image image9 = new Image(db.getImage("inventory",10));
                        ImageView pic9 = new ImageView(db.getImage("inventory",10));
                        GridPane.setConstraints(pic9,1,12);

                        pic0.setFitWidth(50);pic0.setFitHeight(50);
                        pic1.setFitWidth(50);pic1.setFitHeight(50);
                        pic2.setFitWidth(50);pic2.setFitHeight(50);
                        pic3.setFitWidth(50);pic3.setFitHeight(50);
                        pic4.setFitWidth(50);pic4.setFitHeight(50);
                        pic5.setFitWidth(50);pic5.setFitHeight(50);
                        pic6.setFitWidth(50);pic6.setFitHeight(50);
                        pic7.setFitWidth(50);pic7.setFitHeight(50);
                        pic8.setFitWidth(50);pic8.setFitHeight(50);
                        pic9.setFitWidth(50);pic9.setFitHeight(50);

                        layout.getChildren().addAll(rdo0, rdo1, rdo2, rdo3, rdo4, rdo5, rdo6, rdo7, rdo8, rdo9);
                        layout.getChildren().addAll(pic0,pic1,pic2,pic3,pic4,pic5,pic6,pic7,pic8,pic9);
                        db.close();


                    }
                }
                Button addToCart = new Button("Add to Cart");
                GridPane.setConstraints(addToCart,0,13);
                layout.getChildren().add(addToCart);

            }
        });

        tab.setContent(layout);
    }

    //asks user for search word and returns the url string
    public static String getQueryWord(String queryString){


        //format string for the website to scrape
        String urlString = String.format(
                "http://api.walmartlabs.com/v1/search?query=%s&format=xml&apiKey=nz47py7zpfc3xs6pmhfszxdm",
                queryString);

        return urlString;
    }

    //grabs the information from the given url and puts it into an xml file.
    public static void toXMLfile(String website) throws IOException {
        URL urlIn = new URL(website);
        Path pathOut = Paths.get("XMLfiles/Walmart"+getDate()+".xml");
        Files.copy(urlIn.openStream(), pathOut, StandardCopyOption.REPLACE_EXISTING);
    }

    //creates a list of WItems (and information) to be used to insert into the database later
    public static List<WItem> makeList(String fileName){
        //creat a new arraylist of Sections
        List<WItem> inventory = new ArrayList<>();

        //begin the inputfactory
        XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();

        try {
            WItem item = new WItem("","","",
                    "","","",
                    "","","",
                    "","","","");

            //create the eventreader
            XMLEventReader xmlEventReader = xmlInputFactory.createXMLEventReader(
                    new FileInputStream(fileName));

            //go through the file
            while (xmlEventReader.hasNext()) {
                XMLEvent xmlEvent = xmlEventReader.nextEvent();

                if(xmlEvent.isStartElement()){
                    //put the string event in the variable name
                    String event= xmlEvent.asStartElement().getName().getLocalPart();
                    String str;

                    //str = xmlEventReader.getElementText();
                    //System.out.println(event);

                    if(event.equals("itemId")){
                        item = new WItem(null,null,null,
                                null,null, null,
                                null, null, null,
                                null, null, null, null);
                        item.setItemID(xmlEventReader.getElementText());
                    }else if(event.equals("name")){
                        item.setName(xmlEventReader.getElementText());
                    }else if(event.equals("salePrice")){
                        item.setSalePrice(xmlEventReader.getElementText());
                    }else if(event.equals("categoryPath")){
                        item.setCategory(xmlEventReader.getElementText());
                    }else if(event.equals("shortDescription")){
                        item.setShortDesc(xmlEventReader.getElementText());
                    }else if(event.equals("longDescription")){
                        item.setLongDesc(xmlEventReader.getElementText());
                    }else if(event.equals("thumbnailImage")){
                        if(item.getThumbnailImage() == null) {
                            item.setThumbnailImage(xmlEventReader.getElementText());
                        }else{continue;}
                    }else if(event.equals("mediumImage")){
                        if(item.getMediumImage() == null) {
                            item.setMediumImage(xmlEventReader.getElementText());
                        }else {continue;}
                    }else if(event.equals("largeImage")){
                        if(item.getLargeImage() == null) {
                            item.setLargeImage(xmlEventReader.getElementText());
                        }else {continue;}
                    }else if(event.equals("productUrl")){
                        item.setProductURL(xmlEventReader.getElementText());
                    }else if(event.equals("customerRating")){
                        item.setCustRating(xmlEventReader.getElementText());
                    }else if(event.equals("numReviews")){
                        item.setNumReviews(xmlEventReader.getElementText());
                    }else if(event.equals("stock")){
                        item.setAvailability(xmlEventReader.getElementText());
                        inventory.add(item);
                    }
                }//end of if
            }//end of while
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (XMLStreamException e) {
            e.printStackTrace();
        }

        return inventory;
    }

    public static void fillDatabase(List<WItem> inventory, Sqlite db) throws IOException, SQLException {

        db.clear("inventory");

        //insert the items into the database
        for(WItem item: inventory) {
            db.insert("inventory",
                    item.getItemID(), item.getName(), item.getSalePrice(), item.getCategory(), item.getShortDesc(),
                    item.getLongDesc(), item.getThumbnailImage(), item.getMediumImage(), item.getLargeImage(),
                    item.getProductURL(), item.getCustRating(), item.getNumReviews(), item.getAvailability());
        }
    }

    //get the current date for the output filename
    public static String getDate(){
        //get the current date for the output filename
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime now = LocalDateTime.now();
        String date = now.format(dtf);

        return date;
    }
}
